import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../../context/AppContext';
import { ThemeCustomizerPanel } from './ThemeCustomizerPanel';
import { PageContentEditor } from './cms/PageContentEditor';
import { MediaLibrary } from './cms/MediaLibrary';
import { BlogNewsManager } from './cms/BlogNewsManager';
import { ProjectsPropertiesManager } from './cms/ProjectsPropertiesManager';
import { SiteWideSettingsManager } from './cms/SiteWideSettingsManager';
import { RealtorsClubCardsManager } from './cms/RealtorsClubCardsManager';
import { KnowledgeHubManager } from './cms/KnowledgeHubManager';
import { NavigationManager } from './cms/NavigationManager';
import { ServicesManager } from './cms/ServicesManager';
import { AdminHelpGuide } from './AdminHelpGuide';
import { HomePageEditor } from './cms/HomePageEditor';
import { AIWebsiteEditor } from './AIWebsiteEditor';
import { 
  ShieldCheck, 
  Building2, 
  Users, 
  PhoneCall, 
  CheckCircle2, 
  Trash2, 
  Settings, 
  Layers, 
  FileCheck, 
  Search, 
  Palette,
  Eye,
  FileText,
  FolderOpen,
  BookOpen,
  Sliders,
  Sparkles,
  Award,
  GraduationCap,
  Compass,
  Wrench,
  HelpCircle,
  Tag
} from 'lucide-react';
import { formatPriceINR } from '../../utils/propertyUtils';
import { BrokerPortal } from '../broker/BrokerPortal';
import { ServiceProviderPortal } from '../services/ServiceProviderPortal';
import { OffersManager } from './cms/OffersManager';
import { ContactManager } from './ContactManager';

type AdminTab = 
  | 'overview' 
  | 'help'
  | 'home_editor'
  | 'ai_editor'
  | 'cms_pages' 
  | 'cms_navigation'
  | 'cms_media' 
  | 'cms_knowledge_hub'
  | 'cms_blogs' 
  | 'cms_projects_properties' 
  | 'cms_services'
  | 'cms_realtors_clubs'
  | 'cms_sitewide' 
  | 'theme' 
  | 'listings' 
  | 'leads' 
  | 'bookings' 
  | 'settings'
  | 'broker_applications'
  | 'service_provider_applications'
  | 'offers'
  | 'contact';

export const SuperAdminHub: React.FC = () => {
  const { 
    allProperties, 
    deleteProperty, 
    leads, 
    updateLeadStatus, 
    deleteLead, 
    serviceBookings, 
    settings, 
    updateSettings, 
    showToast,
    setActiveView 
  } = useApp();

  const [activeTab, setActiveTabState] = useState<AdminTab>('ai_editor');
  const [searchTerm, setSearchTerm] = useState('');

  // Admin tab navigation history integration.
  //
  // Without this, switching admin tabs never touched browser history, so the
  // very first browser BACK press after opening any tab had nothing in-app
  // to pop to — it fell straight through to whatever page existed before
  // /admin was opened, which on mobile often meant leaving the site or
  // dropping to the home screen. Every tab switch now gets its own history
  // entry (tagged so it doesn't collide with the top-level page navigation
  // already handled by setActiveView), and a popstate listener syncs the
  // local tab state back when the user presses BACK/forward.
  const hasReplacedInitialEntry = useRef(false);
  useEffect(() => {
    if (!hasReplacedInitialEntry.current) {
      hasReplacedInitialEntry.current = true;
      try {
        window.history.replaceState({ ...(window.history.state || {}), adminTab: activeTab }, '');
      } catch {}
    }

    const onPopState = (e: PopStateEvent) => {
      const tab = e.state?.adminTab as AdminTab | undefined;
      if (tab) setActiveTabState(tab);
    };
    window.addEventListener('popstate', onPopState);
    return () => window.removeEventListener('popstate', onPopState);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const setActiveTab = (tab: AdminTab) => {
    setActiveTabState(tab);
    try {
      window.history.pushState({ ...(window.history.state || {}), adminTab: tab }, '');
    } catch {}
  };

  // Stats calculation
  const totalListings = allProperties.length;
  const verifiedListings = allProperties.filter(p => p.verified).length;
  const totalLeads = leads.length;
  const newLeads = leads.filter(l => l.status === 'new').length;
  const totalBookings = serviceBookings.length;

  const handleDeleteListing = (id: string, title: string) => {
    if (confirm(`Are you sure you want to delete listing "${title}"?`)) {
      deleteProperty(id);
      showToast(`Listing ${id} deleted`, 'info');
    }
  };

  // Surfaces the real persistence status from /api/health (see server.ts
  // resolveDataDir()) instead of letting saves silently look fine while
  // actually sitting on a temporary disk that gets wiped. `null` = still
  // checking or backend unreachable, in which case we say nothing rather
  // than guess.
  const [storagePersistent, setStoragePersistent] = useState<boolean | null>(null);
  useEffect(() => {
    let cancelled = false;
    fetch('/api/health')
      .then(res => (res.ok ? res.json() : null))
      .then(data => { if (!cancelled && data) setStoragePersistent(Boolean(data.storagePersistent)); })
      .catch(() => {});
    return () => { cancelled = true; };
  }, []);

  return (
    <div className="bg-[var(--surface-secondary)] min-h-screen py-8 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        
        {/* Hub Header */}
        <div className="bg-gradient-to-r from-[#1E4FA8] via-[#163D85] to-[#122E68] text-white p-6 sm:p-8 rounded-3xl border border-[#163D85] shadow-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="flex items-center space-x-2">
              <span className="bg-amber-400 text-slate-950 text-[10px] font-black uppercase tracking-wider px-2.5 py-0.5 rounded-full shadow-xs">
                Super Admin Access
              </span>
              <span className="text-xs text-blue-200 font-semibold">PIN: Verified</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white flex items-center space-x-2">
              <ShieldCheck className="w-7 h-7 text-amber-300" />
              <span>Auricity Administrative Control Hub</span>
            </h1>
            <p className="text-xs text-blue-100 max-w-2xl">
              Yahan se properties, customer inquiries, website content aur design — sab kuch manage hota hai.
              Naye ho? Neeche "Guide / Madad" tab kholo, wahan har kaam step-by-step simple bhasha mein samjhaya hai.
            </p>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => setActiveView('post-property')}
              className="btn-theme-secondary text-white text-xs font-black px-4 py-2.5 rounded-xl shadow-xs transition-all cursor-pointer"
            >
              + Create Direct Listing
            </button>
          </div>
        </div>

        {storagePersistent === false && (
          <div className="bg-amber-50 border border-amber-300 text-amber-900 rounded-2xl p-4 text-xs sm:text-sm font-semibold flex items-start gap-2">
            <span className="text-lg leading-none">⚠</span>
            <span>
              Server storage is running in temporary mode right now — saves may appear to work but can be lost
              on the next server restart. This needs a proper database connected on the hosting side; it isn't
              something the admin panel can fix on its own. Tell your developer to set this up before relying
              on it for real data.
            </span>
          </div>
        )}

        {/* Navigation Tabs Strip — grouped into simple plain-language categories */}
        <div className="space-y-3">
          {[
            {
              group: 'Shuru Karein',
              items: [
                { id: 'overview', label: 'Dashboard', hint: 'Sab kuch ek nazar mein', icon: Layers },
                { id: 'help', label: 'Guide / Madad', hint: 'Kaise use karein — simple steps', icon: HelpCircle }
              ]
            },
            {
              group: 'Customers',
              items: [
                { id: 'leads', label: `Customer Inquiries (${totalLeads})`, hint: 'Kisne property ke baare mein poocha', icon: Users },
                { id: 'bookings', label: `Service Bookings (${totalBookings})`, hint: 'Packers, legal, cleaning orders', icon: FileCheck }
              ]
            },
            {
              group: 'Properties',
              items: [
                { id: 'listings', label: `Sari Properties (${totalListings})`, hint: 'Add/remove listings', icon: Building2 },
                { id: 'cms_projects_properties', label: 'Projects Manage Karein', hint: 'Bade projects add/edit karein', icon: Building2 },
                { id: 'cms_services', label: 'Services & Rate Card', hint: 'Konsi service, kitne mein', icon: Wrench },
                { id: 'cms_realtors_clubs', label: 'Realtors & Clubs', hint: 'Partner agents ki list', icon: Award },
                { id: 'offers', label: 'Offers & Categories', hint: 'Create, publish and manage offers', icon: Tag },
                { id: 'broker_applications', label: 'Broker Applications', hint: 'Registration & verification review', icon: FileCheck },
                { id: 'service_provider_applications', label: 'Service Providers', hint: 'Provider registration & verification review', icon: Wrench }
              ]
            },
            {
              group: 'Homepage',
              items: [
                { id: 'ai_editor', label: '✨ AI Editor', hint: 'Bas bolo ya screenshot bhejo — AI edit karega', icon: Sparkles },
                { id: 'home_editor', label: '🏠 Home Page Editor', hint: 'Website ko visual mode mein edit karein', icon: Eye }
              ]
            },
            {
              group: 'Website Content',
              items: [
                { id: 'cms_pages', label: 'Website Pages Likhna', hint: 'Text/photo har page ka', icon: FileText },
                { id: 'cms_navigation', label: 'Menu / Top Bar', hint: 'Upar ke links', icon: Compass },
                { id: 'cms_media', label: 'Photos & Images', hint: 'Sari uploaded photos', icon: FolderOpen },
                { id: 'cms_blogs', label: 'Blog & News', hint: 'Articles likhna', icon: BookOpen },
                { id: 'cms_sitewide', label: 'Banners & Offers', hint: 'Homepage ke banner', icon: Sliders },
                { id: 'cms_knowledge_hub', label: 'Broker Training', hint: 'Broker access & guides', icon: GraduationCap }
              ]
            },
            {
              group: 'Design & Settings',
              items: [
                { id: 'theme', label: 'Website Colors', hint: 'Look & design badlein', icon: Palette },
                { id: 'settings', label: 'Contact & Settings', hint: 'Phone, email, address', icon: Settings },
                { id: 'contact', label: 'Contact CMS', hint: 'Page, form, FAQs & messages', icon: PhoneCall }
              ]
            }
          ].map(section => (
            <div key={section.group} className="bg-[var(--surface)] p-3 rounded-2xl border border-[var(--border)] shadow-xs">
              <span className="text-[10px] font-black uppercase tracking-wider text-[var(--text-secondary)] px-1">
                {section.group}
              </span>
              <div className="flex flex-wrap gap-1.5 mt-1.5">
                {section.items.map(tab => {
                  const Icon = tab.icon;
                  const isActive = activeTab === tab.id;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id as any)}
                      title={tab.hint}
                      className={`px-3 py-2 rounded-xl text-xs font-black transition-all flex flex-col items-start cursor-pointer min-w-[120px] ${
                        isActive 
                          ? 'bg-[var(--primary)] text-white shadow-xs' 
                          : 'text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-slate-100'
                      }`}
                    >
                      <span className="flex items-center space-x-1.5">
                        <Icon className="w-4 h-4" />
                        <span>{tab.label}</span>
                      </span>
                      <span className={`text-[9px] font-medium normal-case mt-0.5 ${isActive ? 'text-blue-100' : 'text-[var(--text-secondary)]'}`}>
                        {tab.hint}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>

        {/* Guide / Help Tab */}
        {activeTab === 'help' && (
          <AdminHelpGuide onNavigate={(tab) => setActiveTab(tab as AdminTab)} />
        )}


        {/* AI-FIRST WEBSITE EDITOR */}
        {activeTab === 'ai_editor' && (
          <AIWebsiteEditor />
        )}

        {/* VISUAL HOMEPAGE EDITOR */}
        {activeTab === 'home_editor' && (
          <HomePageEditor />
        )}

        {/* CMS TAB 1: Page Content Editor */}
        {activeTab === 'cms_pages' && (
          <PageContentEditor />
        )}

        {/* CMS TAB: Navigation Management */}
        {activeTab === 'cms_navigation' && (
          <NavigationManager />
        )}

        {/* CMS TAB 2: Media Vault */}
        {activeTab === 'cms_media' && (
          <MediaLibrary />
        )}

        {/* CMS TAB: Knowledge Hub & Broker Access CMS */}
        {activeTab === 'cms_knowledge_hub' && (
          <KnowledgeHubManager />
        )}

        {/* CMS TAB 3: Blog & News Manager */}
        {activeTab === 'cms_blogs' && (
          <BlogNewsManager />
        )}

        {/* CMS TAB 4: Projects & Properties CMS */}
        {activeTab === 'cms_projects_properties' && (
          <ProjectsPropertiesManager />
        )}

        {/* CMS TAB: Services & Rate Cards CMS */}
        {activeTab === 'cms_services' && (
          <ServicesManager />
        )}

        {/* CMS TAB: Offers */}
        {activeTab === 'offers' && <OffersManager />}

        {activeTab === 'contact' && <ContactManager />}

        {/* CMS TAB: Realtors & Two Club Cards CMS */}
        {activeTab === 'broker_applications' && (<BrokerAdminTab />)}

        {activeTab === 'service_provider_applications' && (<ServiceProviderPortal mode="admin" />)}

        {activeTab === 'cms_realtors_clubs' && (
          <RealtorsClubCardsManager />
        )}

        {/* CMS TAB 5: Site-Wide Settings & Banners */}
        {activeTab === 'cms_sitewide' && (
          <SiteWideSettingsManager />
        )}

        {/* TAB: Theme & Appearance Customizer */}
        {activeTab === 'theme' && (
          <ThemeCustomizerPanel />
        )}

        {/* Tab 1: Overview Dashboard */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            {/* KPI Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <div className="bg-[var(--surface)] p-5 rounded-3xl border border-[var(--border)] shadow-xs space-y-1">
                <span className="text-[10px] font-bold text-[var(--text-secondary)] uppercase">Total Active Listings</span>
                <p className="text-2xl font-black text-[var(--primary)]">{totalListings}</p>
                <span className="text-[10px] text-emerald-600 font-bold">{verifiedListings} Auricity Verified</span>
              </div>

              <div className="bg-[var(--surface)] p-5 rounded-3xl border border-[var(--border)] shadow-xs space-y-1">
                <span className="text-[10px] font-bold text-[var(--text-secondary)] uppercase">Pending Inquiries</span>
                <p className="text-2xl font-black text-[var(--secondary)]">{newLeads}</p>
                <span className="text-[10px] text-[var(--text-secondary)] font-medium">{totalLeads} Total CRM Leads</span>
              </div>

              <div className="bg-[var(--surface)] p-5 rounded-3xl border border-[var(--border)] shadow-xs space-y-1">
                <span className="text-[10px] font-bold text-[var(--text-secondary)] uppercase">Doorstep Orders</span>
                <p className="text-2xl font-black text-emerald-600">{totalBookings}</p>
                <span className="text-[10px] text-[var(--text-secondary)] font-medium">Packers, Legal & Clean</span>
              </div>

              <div className="bg-[var(--surface)] p-5 rounded-3xl border border-[var(--border)] shadow-xs space-y-1">
                <span className="text-[10px] font-bold text-[var(--text-secondary)] uppercase">Commission Saved</span>
                <p className="text-2xl font-black text-indigo-600">₹42.8 Lakh</p>
                <span className="text-[10px] text-[var(--text-secondary)] font-medium">0% Brokerage Model</span>
              </div>
            </div>

            {/* Quick Theme Customizer Promotion banner */}
            <div className="bg-[var(--surface)] p-6 rounded-3xl border border-[var(--border)] shadow-xs flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="space-y-1">
                <span className="text-xs font-bold text-[var(--secondary)] uppercase tracking-wider">Dynamic Styling Engine</span>
                <h3 className="text-base font-black text-[var(--text-primary)]">
                  Personalize the Website Colors & Button Styles
                </h3>
                <p className="text-xs text-[var(--text-secondary)]">
                  Switch presets, pick custom HEX brand colors, adjust corner radii, and preview in real-time.
                </p>
              </div>
              <button
                onClick={() => setActiveTab('theme')}
                className="btn-theme-primary text-xs font-bold px-4 py-2 rounded-xl shadow-xs whitespace-nowrap cursor-pointer"
              >
                Open Theme Customizer →
              </button>
            </div>

            {/* Recent Leads Preview */}
            <div className="bg-[var(--surface)] p-6 rounded-3xl border border-[var(--border)] shadow-xs space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-black text-sm text-[var(--text-primary)] uppercase tracking-wider">
                  Latest Inquiries & Site Visit Requests
                </h3>
                <button
                  onClick={() => setActiveTab('leads')}
                  className="text-xs font-bold text-[var(--primary)] hover:underline cursor-pointer"
                >
                  View all leads →
                </button>
              </div>

              <div className="divide-y divide-slate-100">
                {leads.slice(0, 4).map(lead => (
                  <div key={lead.id} className="py-3 flex items-center justify-between text-xs">
                    <div>
                      <div className="font-bold text-[var(--text-primary)]">{lead.name} • <span className="text-[var(--primary)] font-mono">{lead.phone}</span></div>
                      <div className="text-[11px] text-[var(--text-secondary)]">{lead.propertyTitle || 'General Locality Inquiry'} ({lead.preferredLocality})</div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase ${
                        lead.status === 'new' ? 'bg-amber-100 text-amber-800' : 'bg-emerald-100 text-emerald-800'
                      }`}>
                        {lead.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Property Listings Management */}
        {activeTab === 'listings' && (
          <div className="bg-[var(--surface)] p-6 rounded-3xl border border-[var(--border)] shadow-xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <h3 className="font-black text-base text-[var(--text-primary)]">
                Portal Property Inventory ({allProperties.length})
              </h3>
              <div className="relative max-w-xs w-full">
                <Search className="w-3.5 h-3.5 text-[var(--text-secondary)] absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Filter listings..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-8 pr-3 py-1.5 bg-[var(--surface-secondary)] border border-[var(--border)] rounded-xl text-xs"
                />
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 text-[var(--text-secondary)] font-bold uppercase text-[10px]">
                    <th className="py-3 px-3">Property</th>
                    <th className="py-3 px-3">Type</th>
                    <th className="py-3 px-3">Price</th>
                    <th className="py-3 px-3">Locality</th>
                    <th className="py-3 px-3">Contact</th>
                    <th className="py-3 px-3">Verified</th>
                    <th className="py-3 px-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {allProperties
                    .filter(p => p.title.toLowerCase().includes(searchTerm.toLowerCase()) || p.locality.toLowerCase().includes(searchTerm.toLowerCase()))
                    .map(prop => (
                      <tr key={prop.id} className="hover:bg-slate-50">
                        <td className="py-3 px-3 font-bold text-[var(--text-primary)] max-w-xs truncate">
                          {prop.title}
                        </td>
                        <td className="py-3 px-3 uppercase text-[10px] font-bold">
                          {prop.listingType}
                        </td>
                        <td className="py-3 px-3 font-black text-[var(--primary)]">
                          {formatPriceINR(prop.price)}
                        </td>
                        <td className="py-3 px-3 text-[var(--text-secondary)]">
                          {prop.locality}
                        </td>
                        <td className="py-3 px-3 font-mono text-[11px]">
                          {prop.contactPhone}
                        </td>
                        <td className="py-3 px-3">
                          <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                            prop.verified ? 'bg-emerald-100 text-emerald-700' : 'bg-slate-100 text-[var(--text-secondary)]'
                          }`}>
                            {prop.verified ? 'Verified' : 'Pending'}
                          </span>
                        </td>
                        <td className="py-3 px-3 text-right space-x-1">
                          <button
                            onClick={() => handleDeleteListing(prop.id, prop.title)}
                            className="p-1.5 rounded-lg text-rose-600 hover:bg-rose-50 cursor-pointer"
                            title="Delete Listing"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Tab 3: Leads Management */}
        {activeTab === 'leads' && (
          <div className="bg-[var(--surface)] p-6 rounded-3xl border border-[var(--border)] shadow-xs space-y-4">
            <h3 className="font-black text-base text-[var(--text-primary)]">
              Inquiry Leads & Buyer Matching Hub ({leads.length})
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {leads.map(lead => (
                <div key={lead.id} className="p-4 rounded-2xl bg-[var(--surface-secondary)] border border-[var(--border)] space-y-3">
                  <div className="flex items-start justify-between">
                    <div>
                      <h4 className="font-black text-sm text-[var(--text-primary)]">{lead.name}</h4>
                      <p className="text-xs font-mono text-[var(--primary)] font-bold">{lead.phone}</p>
                    </div>
                    <select
                      value={lead.status}
                      onChange={(e) => {
                        updateLeadStatus(lead.id, e.target.value as any);
                        showToast('Lead status updated', 'success');
                      }}
                      className="text-xs font-bold bg-[var(--surface)] border border-[var(--border)] rounded-xl px-2 py-1 cursor-pointer"
                    >
                      <option value="new">New Inquiry</option>
                      <option value="contacted">Contacted</option>
                      <option value="site_visit_scheduled">Site Visit Scheduled</option>
                      <option value="closed">Deal Closed</option>
                      <option value="lost">Lost</option>
                    </select>
                  </div>

                  <div className="text-xs text-[var(--text-secondary)] space-y-1">
                    <div><strong>Inquiry:</strong> {lead.propertyTitle || 'General'}</div>
                    <div><strong>Locality:</strong> {lead.preferredLocality} • <strong>Budget:</strong> {lead.budget || 'Flexible'}</div>
                    {lead.message && <div className="italic bg-[var(--surface)] p-2 rounded-xl border border-slate-200/60 mt-1">{lead.message}</div>}
                  </div>

                  <div className="pt-2 border-t border-slate-200/60 flex items-center justify-between">
                    <a
                      href={`https://wa.me/${lead.phone.replace(/[^0-9]/g, '')}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-bold px-3 py-1.5 rounded-lg flex items-center space-x-1"
                    >
                      <PhoneCall className="w-3 h-3" />
                      <span>WhatsApp Buyer</span>
                    </a>
                    <button
                      onClick={() => {
                        if (confirm(`Delete the inquiry from "${lead.name}"? This cannot be undone.`)) {
                          deleteLead(lead.id);
                        }
                      }}
                      className="text-rose-600 hover:text-rose-800 text-xs font-bold cursor-pointer"
                    >
                      Delete
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tab 4: Service Bookings */}
        {activeTab === 'bookings' && (
          <div className="bg-[var(--surface)] p-6 rounded-3xl border border-[var(--border)] shadow-xs space-y-4">
            <h3 className="font-black text-base text-[var(--text-primary)]">
              Doorstep Service Bookings ({serviceBookings.length})
            </h3>

            <div className="space-y-3">
              {serviceBookings.map((b, i) => (
                <div key={i} className="p-4 rounded-2xl bg-[var(--surface-secondary)] border border-[var(--border)] flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                  <div>
                    <div className="font-bold text-sm text-[var(--text-primary)]">{b.serviceTitle}</div>
                    <div className="text-[var(--text-secondary)]">Client: <strong>{b.userName}</strong> ({b.userPhone}) • Locality: <strong>{b.locality}</strong></div>
                    {b.notes && <div className="text-[11px] text-slate-500 mt-0.5">Notes: {b.notes}</div>}
                  </div>
                  <div className="flex items-center space-x-3">
                    <span className="bg-emerald-100 text-emerald-800 text-[10px] font-black px-2.5 py-1 rounded-full uppercase">
                      {b.status}
                    </span>
                    <a
                      href={`https://wa.me/${b.userPhone}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="bg-emerald-600 text-white px-3 py-1.5 rounded-xl font-bold"
                    >
                      WhatsApp Pro
                    </a>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Tab 5: Settings */}
        {activeTab === 'settings' && (
          <div className="bg-[var(--surface)] p-6 rounded-3xl border border-[var(--border)] shadow-xs space-y-6 max-w-2xl">
            <h3 className="font-black text-base text-[var(--text-primary)]">
              Portal Master Settings & Rules
            </h3>

            <div className="space-y-4 text-xs">
              <div>
                <label className="font-bold text-[var(--text-primary)] block mb-1">Master Support Helpline</label>
                <input
                  type="text"
                  value={settings.supportPhone}
                  onChange={(e) => updateSettings({ supportPhone: e.target.value })}
                  className="w-full px-3 py-2 bg-[var(--surface-secondary)] border border-[var(--border)] rounded-xl font-mono text-xs"
                />
              </div>

              <div>
                <label className="font-bold text-[var(--text-primary)] block mb-1">Support Email</label>
                <input
                  type="email"
                  value={settings.supportEmail}
                  onChange={(e) => updateSettings({ supportEmail: e.target.value })}
                  className="w-full px-3 py-2 bg-[var(--surface-secondary)] border border-[var(--border)] rounded-xl text-xs"
                />
              </div>

              <div>
                <label className="font-bold text-[var(--text-primary)] block mb-1">Office Address</label>
                <input
                  type="text"
                  value={settings.officeAddress}
                  onChange={(e) => updateSettings({ officeAddress: e.target.value })}
                  className="w-full px-3 py-2 bg-[var(--surface-secondary)] border border-[var(--border)] rounded-xl text-xs"
                />
              </div>

              <div className="pt-2">
                <button
                  onClick={() => showToast('Platform configuration saved', 'success')}
                  className="btn-theme-primary px-6 py-2.5 rounded-xl font-bold text-xs shadow-xs"
                >
                  Save Platform Settings
                </button>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};


const BrokerAdminTab: React.FC = () => <BrokerPortal mode="admin" />;
