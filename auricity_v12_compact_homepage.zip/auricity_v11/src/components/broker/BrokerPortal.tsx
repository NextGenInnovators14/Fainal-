import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowRight, ArrowLeft, BadgeCheck, BarChart3, Bell, Building2, Check, CheckCircle2,
  ChevronDown, ChevronRight, ClipboardCheck, Clock3, FileCheck2, FileText, Globe2,
  Home, KeyRound, LayoutDashboard, LockKeyhole, MapPin, Menu, MessageSquare, Pencil,
  Search, ShieldCheck, Sparkles, UploadCloud, UserRound, Users, X, XCircle, Plus, Eye,
  MoreHorizontal, AlertCircle
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import type { Realtor } from '../../types';

const API_KEY = 'auricity_broker_applications_v1';

type BrokerStatus = 'under_review' | 'approved' | 'rejected' | 'more_information_required';
type Specialization = 'Residential' | 'Commercial' | 'Land' | 'Rental' | 'Luxury' | 'Other';

type BrokerDocument = { id: string; name: string; type: string; size: number; uploadedAt: string; storageKey?: string };
type BrokerApplication = {
  id: string;
  applicationId: string;
  submittedAt: string;
  updatedAt: string;
  status: BrokerStatus;
  personal: { fullName: string; email: string; mobile: string; profilePhoto?: string; city: string; state: string; preferredLanguage: string };
  professional: { agencyName: string; yearsExperience: string; specialization: Specialization[]; areasServed: string; bio: string };
  business: { officeAddress: string; businessPhone: string; website: string; businessDescription: string; activeProperties: string; preferredPropertyTypes: string };
  verification: { idType: string; documents: BrokerDocument[]; businessRegistration: string; agreement: boolean };
  reviewerNotes?: string;
  createdByUserId?: string;
};

type FormState = Omit<BrokerApplication, 'id' | 'applicationId' | 'submittedAt' | 'updatedAt' | 'status'>;

const emptyForm: FormState = {
  personal: { fullName: '', email: '', mobile: '', city: '', state: '', preferredLanguage: 'English' },
  professional: { agencyName: '', yearsExperience: '', specialization: [], areasServed: '', bio: '' },
  business: { officeAddress: '', businessPhone: '', website: '', businessDescription: '', activeProperties: '', preferredPropertyTypes: '' },
  verification: { idType: '', documents: [], businessRegistration: '', agreement: false }
};

const fieldClass = (invalid?: boolean) => `w-full rounded-2xl border ${invalid ? 'border-red-300 ring-2 ring-red-100' : 'border-slate-200'} bg-white px-4 py-3 text-sm text-slate-900 outline-none transition focus:border-[#214E9B] focus:ring-4 focus:ring-blue-100`;

async function loadApplications(): Promise<BrokerApplication[]> {
  try {
    const r = await fetch(`/api/store/${API_KEY}`);
    if (!r.ok) return JSON.parse(localStorage.getItem(API_KEY) || '[]');
    const data = await r.json();
    const value = Array.isArray(data?.value) ? data.value : [];
    localStorage.setItem(API_KEY, JSON.stringify(value));
    return value;
  } catch {
    try { return JSON.parse(localStorage.getItem(API_KEY) || '[]'); } catch { return []; }
  }
}

async function saveApplications(applications: BrokerApplication[]) {
  localStorage.setItem(API_KEY, JSON.stringify(applications));
  try { await fetch(`/api/store/${API_KEY}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ value: applications }) }); } catch {}
}

function makeApplicationId() {
  return `AUR-BR-${new Date().getFullYear()}-${Math.random().toString(36).slice(2, 8).toUpperCase()}`;
}

function SectionHeading({ eyebrow, title, description }: { eyebrow: string; title: string; description?: string }) {
  return <div className="max-w-3xl">
    <p className="mb-2 text-xs font-extrabold uppercase tracking-[0.22em] text-[#B68A32]">{eyebrow}</p>
    <h2 className="text-3xl font-black tracking-tight text-slate-950 sm:text-4xl">{title}</h2>
    {description && <p className="mt-3 text-base leading-7 text-slate-600">{description}</p>}
  </div>;
}

function StatusPill({ status }: { status: BrokerStatus }) {
  const map = {
    under_review: ['Under Review', 'bg-amber-50 text-amber-700 border-amber-200'],
    approved: ['Approved', 'bg-emerald-50 text-emerald-700 border-emerald-200'],
    rejected: ['Rejected', 'bg-red-50 text-red-700 border-red-200'],
    more_information_required: ['More Information Required', 'bg-blue-50 text-blue-700 border-blue-200']
  } as const;
  const [label, cls] = map[status];
  return <span className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-xs font-extrabold ${cls}`}><span className="h-1.5 w-1.5 rounded-full bg-current" />{label}</span>;
}

export const BrokerPortal: React.FC<{ mode: 'landing' | 'register' | 'status' | 'dashboard' | 'admin' }> = ({ mode }) => {
  const { setActiveView, activeRole, realtors, settings, showToast, allProperties, leads } = useApp();
  const [applications, setApplications] = useState<BrokerApplication[]>([]);
  const [selected, setSelected] = useState<BrokerApplication | null>(null);
  const [loading, setLoading] = useState(true);
  const [form, setForm] = useState<FormState>(emptyForm);
  const [step, setStep] = useState(1);
  const [submitted, setSubmitted] = useState<BrokerApplication | null>(null);
  const [draftSaved, setDraftSaved] = useState(false);
  const [uploadError, setUploadError] = useState('');
  const [filePayloads, setFilePayloads] = useState<Record<string, { data: string; name: string; type: string; size: number }>>({});
  const [adminFilter, setAdminFilter] = useState<'all' | BrokerStatus>('all');
  const [adminSearch, setAdminSearch] = useState('');
  const [mobileAdminMenu, setMobileAdminMenu] = useState(false);
  const [reviewNote, setReviewNote] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const draftTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => { loadApplications().then(a => { setApplications(a); setLoading(false); }); }, []);

  useEffect(() => {
    if (mode !== 'register') return;
    try {
      const draft = localStorage.getItem(`${API_KEY}_draft`);
      if (draft) setForm(JSON.parse(draft));
    } catch {}
  }, [mode]);

  useEffect(() => {
    if (mode !== 'register') return;
    if (draftTimer.current) clearTimeout(draftTimer.current);
    draftTimer.current = setTimeout(() => {
      localStorage.setItem(`${API_KEY}_draft`, JSON.stringify(form));
      setDraftSaved(true);
      setTimeout(() => setDraftSaved(false), 1600);
    }, 450);
    return () => { if (draftTimer.current) clearTimeout(draftTimer.current); };
  }, [form, mode]);

  const go = (view: string) => setActiveView(view);
  const update = <K extends keyof FormState>(section: K, key: string, value: any) => setForm(prev => ({ ...prev, [section]: { ...(prev[section] as any), [key]: value } }));
  const toggleSpecialization = (value: Specialization) => setForm(prev => ({ ...prev, professional: { ...prev.professional, specialization: prev.professional.specialization.includes(value) ? prev.professional.specialization.filter(x => x !== value) : [...prev.professional.specialization, value] } }));

  const validateStep = (s: number) => {
    if (s === 1) return ['fullName', 'email', 'mobile', 'city', 'state'].every(k => String((form.personal as any)[k]).trim());
    if (s === 2) return ['agencyName', 'yearsExperience', 'areasServed', 'bio'].every(k => String((form.professional as any)[k]).trim()) && form.professional.specialization.length > 0;
    if (s === 3) return ['officeAddress', 'businessPhone', 'businessDescription', 'activeProperties', 'preferredPropertyTypes'].every(k => String((form.business as any)[k]).trim());
    if (s === 4) return Boolean(form.verification.idType && form.verification.documents.length && form.verification.agreement);
    return true;
  };

  const submit = async () => {
    if (!validateStep(4)) return;
    setSubmitting(true);
    const now = new Date().toISOString();
    const uploadedDocuments = await Promise.all(form.verification.documents.map(async (doc) => {
      const payload = filePayloads[doc.id];
      if (!payload) return doc;
      try {
        const r = await fetch('/api/broker/documents', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
        if (r.ok) { const saved = await r.json(); return { ...doc, storageKey: saved.storageKey }; }
      } catch {}
      return doc;
    }));
    const applicationForm = { ...form, verification: { ...form.verification, documents: uploadedDocuments } };
    const app: BrokerApplication = {
      id: crypto.randomUUID?.() || `app-${Date.now()}`,
      applicationId: makeApplicationId(), submittedAt: now, updatedAt: now, status: 'under_review', ...form
    };
    const next = [app, ...applications.filter(x => x.personal.email.toLowerCase() !== app.personal.email.toLowerCase())];
    await saveApplications(next);
    setApplications(next); setSubmitted(app); localStorage.removeItem(`${API_KEY}_draft`); setSubmitting(false); showToast('Broker registration submitted successfully.', 'success');
  };

  const updateApplication = async (app: BrokerApplication, patch: Partial<BrokerApplication>) => {
    const next = applications.map(a => a.id === app.id ? { ...a, ...patch, updatedAt: new Date().toISOString() } : a);
    await saveApplications(next); setApplications(next); setSelected({ ...app, ...patch });
  };

  const dashboardApp = applications[0];
  const filteredApplications = useMemo(() => applications.filter(a => (adminFilter === 'all' || a.status === adminFilter) && `${a.personal.fullName} ${a.personal.email} ${a.personal.mobile} ${a.professional.agencyName} ${a.applicationId}`.toLowerCase().includes(adminSearch.toLowerCase())), [applications, adminFilter, adminSearch]);

  if (mode === 'landing') return <Landing go={go} />;

  if (mode === 'register') return <Registration form={form} step={step} setStep={setStep} update={update} toggleSpecialization={toggleSpecialization} validateStep={validateStep} submit={submit} submitting={submitting} draftSaved={draftSaved} uploadError={uploadError} setUploadError={setUploadError} setForm={setForm} setFilePayloads={setFilePayloads} go={go} submitted={submitted} />;

  if (mode === 'status') return <StatusPage applications={applications} loading={loading} go={go} onSelect={setSelected} selected={selected} />;

  if (mode === 'admin') {
    if (activeRole !== 'admin') return <AccessDenied go={go} />;
    const stats = { total: applications.length, pending: applications.filter(a => a.status === 'under_review').length, approved: applications.filter(a => a.status === 'approved').length, rejected: applications.filter(a => a.status === 'rejected').length };
    return <AdminPortal adminPin={settings.adminPin} applications={filteredApplications} allApplications={applications} stats={stats} filter={adminFilter} setFilter={setAdminFilter} search={adminSearch} setSearch={setAdminSearch} selected={selected} setSelected={setSelected} note={reviewNote} setNote={setReviewNote} updateApplication={updateApplication} mobileMenu={mobileAdminMenu} setMobileMenu={setMobileAdminMenu} go={go} />;
  }

  return <BrokerDashboard app={dashboardApp} allProperties={allProperties} leads={leads} realtors={realtors} go={go} />;
};

function Landing({ go }: { go: (v: string) => void }) {
  const benefits = [
    [BadgeCheck, 'Verified Broker Profile', 'Build trust with a professional verified profile.'],
    [Building2, 'More Property Visibility', 'Showcase your properties to a wider audience.'],
    [Users, 'Qualified Leads', 'Connect with potential buyers and sellers.'],
    [LayoutDashboard, 'Professional Dashboard', 'Manage listings, leads and enquiries from one place.'],
    [Bell, 'Real-Time Notifications', 'Get notified about new enquiries and leads.'],
    [Sparkles, 'Build Your Reputation', 'Grow your professional presence on Auricity.']
  ] as const;
  const steps = ['Register', 'Submit Verification Details', 'Get Verified', 'Start Listing & Receiving Leads'];
  const faqs = ['Who can become an Auricity broker?', 'How does broker verification work?', 'Can I add multiple properties?', 'How do I receive leads?', 'Can I edit my property listings?', 'Is there a broker dashboard?'];
  return <div className="bg-[#F7F9FC] text-slate-950">
    <section className="relative overflow-hidden bg-[#081A38]">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_75%_20%,rgba(62,113,210,.35),transparent_32%),radial-gradient(circle_at_10%_80%,rgba(182,138,50,.16),transparent_28%)]" />
      <div className="relative mx-auto grid max-w-7xl items-center gap-12 px-5 py-16 sm:px-8 lg:grid-cols-[1.05fr_.95fr] lg:px-10 lg:py-24">
        <div>
          <span className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/10 px-4 py-2 text-xs font-bold text-blue-100 backdrop-blur"><ShieldCheck className="h-4 w-4 text-[#D9B45B]" /> Auricity Broker Network</span>
          <h1 className="mt-6 max-w-3xl text-4xl font-black tracking-[-.045em] text-white sm:text-6xl lg:text-7xl">Grow Your Real Estate Business with Auricity</h1>
          <p className="mt-6 max-w-2xl text-base leading-7 text-blue-100 sm:text-lg">Join Auricity as a verified broker and connect with qualified property buyers, sellers and investors.</p>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row"><button onClick={() => go('broker-register')} className="group rounded-2xl bg-white px-6 py-3.5 text-sm font-black text-[#102B59] shadow-xl transition hover:-translate-y-0.5">Become a Broker <ArrowRight className="ml-2 inline h-4 w-4 transition group-hover:translate-x-1" /></button><button onClick={() => document.getElementById('broker-benefits')?.scrollIntoView({ behavior: 'smooth' })} className="rounded-2xl border border-white/20 bg-white/5 px-6 py-3.5 text-sm font-black text-white backdrop-blur transition hover:bg-white/10">Explore Benefits</button></div>
          <div className="mt-10 flex flex-wrap gap-x-6 gap-y-3 text-xs font-semibold text-blue-200"><span>Secure account</span><span>•</span><span>Verified profiles</span><span>•</span><span>Professional listings</span></div>
        </div>
        <div className="relative mx-auto w-full max-w-xl">
          <div className="overflow-hidden rounded-[2rem] border border-white/15 bg-white/10 p-2 shadow-2xl backdrop-blur"><img src="https://images.unsplash.com/photo-1560518883-ce09059eeffa?auto=format&fit=crop&w=1200&q=85" className="h-[360px] w-full rounded-[1.5rem] object-cover sm:h-[470px]" alt="Professional real estate broker" /></div>
          {[[BadgeCheck,'Verified Broker','Profile approved'],[Users,'New Leads','Qualified enquiries'],[Building2,'Properties Listed','Manage your inventory'],[CheckCircle2,'Successful Deals','Track your pipeline']].map(([Icon,title,sub],i)=><div key={title as string} className={`absolute hidden rounded-2xl border border-white/50 bg-white/95 p-3 shadow-2xl backdrop-blur sm:block ${i===0?'left-0 top-12':i===1?'right-0 top-28':i===2?'left-0 bottom-20':'right-0 bottom-8'}`}><div className="flex items-center gap-3"><div className="rounded-xl bg-[#EEF4FF] p-2 text-[#214E9B]"><Icon className="h-4 w-4" /></div><div><p className="text-xs font-black text-slate-900">{title as string}</p><p className="text-[10px] text-slate-500">{sub as string}</p></div></div></div>)}
        </div>
      </div>
    </section>

    <section id="broker-benefits" className="mx-auto max-w-7xl px-5 py-16 sm:px-8 lg:px-10 lg:py-24"><SectionHeading eyebrow="Why Join Auricity?" title="A better operating layer for modern brokers" description="Bring your professional profile, property inventory and lead workflow into one focused platform." /><div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{benefits.map(([Icon,title,desc])=><div key={title} className="group rounded-3xl border border-slate-200 bg-white p-6 shadow-sm transition duration-300 hover:-translate-y-1 hover:border-blue-200 hover:shadow-xl"><div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#EEF4FF] text-[#214E9B] transition group-hover:bg-[#214E9B] group-hover:text-white"><Icon className="h-5 w-5" /></div><h3 className="mt-5 text-lg font-black">{title}</h3><p className="mt-2 text-sm leading-6 text-slate-600">{desc}</p></div>)}</div></section>

    <section className="bg-white px-5 py-16 sm:px-8 lg:px-10 lg:py-24"><div className="mx-auto max-w-7xl"><SectionHeading eyebrow="How It Works" title="From registration to your first lead" /><div className="mt-12 grid gap-5 md:grid-cols-4">{steps.map((s,i)=><div key={s} className="relative rounded-3xl border border-slate-200 p-6"><div className="flex h-11 w-11 items-center justify-center rounded-full bg-[#0D2C5C] text-sm font-black text-white">{i+1}</div><h3 className="mt-5 font-black">{s}</h3>{i<steps.length-1&&<div className="absolute right-[-1.2rem] top-11 z-10 hidden h-px w-6 bg-slate-200 md:block" />}</div>)}</div></div></section>

    <section className="mx-auto max-w-7xl px-5 py-16 sm:px-8 lg:px-10 lg:py-24"><div className="grid items-center gap-10 lg:grid-cols-[.9fr_1.1fr]"><div><SectionHeading eyebrow="Broker Dashboard" title="Everything you need to run your pipeline" description="A focused workspace for listings, leads, enquiries, notifications and performance." /><button onClick={() => go('broker-register')} className="mt-7 rounded-2xl bg-[#102B59] px-6 py-3.5 text-sm font-black text-white transition hover:bg-[#214E9B]">Create Your Broker Account <ArrowRight className="ml-2 inline h-4 w-4" /></button></div><DashboardMock /></div></section>

    <section className="bg-[#081A38] px-5 py-16 text-white sm:px-8 lg:px-10 lg:py-24"><div className="mx-auto max-w-7xl"><SectionHeading eyebrow="Trust" title="A Professional Platform Built for Modern Brokers" description="Built around clear workflows, account security and professional presentation — without unverifiable claims." /><div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-5">{['Secure account','Verified profiles','Professional listings','Lead management','Transparent communication'].map((x,i)=><div key={x} className="rounded-2xl border border-white/10 bg-white/5 p-5"><CheckCircle2 className="h-5 w-5 text-[#D9B45B]" /><p className="mt-4 text-sm font-bold text-white">{x}</p></div>)}</div></div></section>

    <section className="mx-auto max-w-5xl px-5 py-16 sm:px-8 lg:py-24"><SectionHeading eyebrow="FAQ" title="Questions brokers usually ask" /><div className="mt-8 divide-y divide-slate-200 rounded-3xl border border-slate-200 bg-white">{faqs.map(q=><details key={q} className="group p-5"><summary className="flex cursor-pointer list-none items-center justify-between text-sm font-black">{q}<ChevronDown className="h-4 w-4 transition group-open:rotate-180" /></summary><p className="mt-3 max-w-3xl text-sm leading-6 text-slate-600">Auricity will guide you through the registration and verification process. Access and listing capabilities depend on your account status and the information approved by the Auricity team.</p></details>)}</div></section>

    <section className="px-5 pb-16 sm:px-8 lg:px-10"><div className="mx-auto max-w-6xl overflow-hidden rounded-[2rem] bg-gradient-to-br from-[#102B59] to-[#214E9B] px-7 py-10 text-center text-white sm:px-12 sm:py-14"><Sparkles className="mx-auto h-7 w-7 text-[#D9B45B]" /><h2 className="mt-4 text-3xl font-black sm:text-4xl">Ready to build your professional presence?</h2><p className="mx-auto mt-3 max-w-2xl text-sm leading-6 text-blue-100">Create your broker profile, submit verification details and manage your application from one place.</p><button onClick={() => go('broker-register')} className="mt-7 rounded-2xl bg-white px-6 py-3.5 text-sm font-black text-[#102B59]">Become a Broker <ArrowRight className="ml-2 inline h-4 w-4" /></button></div></section>
  </div>;
}

function DashboardMock() { return <div className="rounded-[2rem] border border-slate-200 bg-white p-4 shadow-2xl"><div className="rounded-[1.5rem] bg-[#F7F9FC] p-4 sm:p-6"><div className="flex items-center justify-between"><div><p className="text-xs font-bold text-slate-500">Broker Workspace</p><h3 className="mt-1 text-lg font-black">Overview</h3></div><div className="rounded-xl bg-white p-2 shadow-sm"><Bell className="h-4 w-4 text-slate-500" /></div></div><div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-4">{[['Total Listings','—'],['Active Listings','—'],['New Leads','—'],['Property Views','—']].map(([a,b])=><div key={a} className="rounded-2xl border border-slate-200 bg-white p-4"><p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">{a}</p><p className="mt-2 text-2xl font-black text-[#102B59]">{b}</p></div>)}</div><div className="mt-4 grid gap-3 sm:grid-cols-2"><div className="rounded-2xl border border-slate-200 bg-white p-4"><p className="text-xs font-black">Recent Leads</p><div className="mt-4 space-y-3">{[1,2,3].map(i=><div key={i} className="h-10 rounded-xl bg-slate-100" />)}</div></div><div className="rounded-2xl border border-slate-200 bg-white p-4"><p className="text-xs font-black">Recent Properties</p><div className="mt-4 space-y-3">{[1,2,3].map(i=><div key={i} className="h-10 rounded-xl bg-slate-100" />)}</div></div></div></div></div>; }

function Registration(props: any) {
  const { form, step, setStep, update, toggleSpecialization, validateStep, submit, submitting, draftSaved, uploadError, setUploadError, setForm, setFilePayloads, go, submitted } = props;
  if (submitted) return <SuccessScreen application={submitted} go={go} />;
  const titles = ['Personal Information','Professional Information','Business Details','Verification','Review & Submit'];
  const handleFile = (file: File) => {
    setUploadError('');
    const allowed = ['application/pdf','image/jpeg','image/png'];
    if (!allowed.includes(file.type)) return setUploadError('Upload a PDF, JPG or PNG file.');
    if (file.size > 5 * 1024 * 1024) return setUploadError('Maximum file size is 5 MB.');
    const reader = new FileReader();
    reader.onload = () => {
      const id = crypto.randomUUID?.() || `doc-${Date.now()}`;
      const doc: BrokerDocument = { id, name: file.name, type: file.type, size: file.size, uploadedAt: new Date().toISOString() };
      const data = String(reader.result || '');
      setFilePayloads(prev => ({ ...prev, [id]: { data: data.includes(',') ? data.split(',')[1] : data, name: file.name, type: file.type, size: file.size } }));
      setForm((prev: FormState) => ({ ...prev, verification: { ...prev.verification, documents: [...prev.verification.documents, doc] } }));
    };
    reader.readAsDataURL(file);
  };
  return <div className="min-h-screen bg-[#F7F9FC]"><div className="mx-auto max-w-5xl px-5 py-10 sm:px-8 lg:py-16"><div className="mb-8 flex items-center justify-between"><button onClick={() => go('broker-landing')} className="inline-flex items-center gap-2 text-sm font-bold text-slate-600"><ArrowLeft className="h-4 w-4" /> Back to Broker Page</button><span className="text-xs font-bold text-slate-400">{draftSaved ? 'Draft saved' : 'Your progress is saved automatically'}</span></div><div className="rounded-[2rem] border border-slate-200 bg-white p-5 shadow-xl sm:p-8"><div className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between"><div><p className="text-xs font-extrabold uppercase tracking-[.2em] text-[#B68A32]">Broker Registration</p><h1 className="mt-2 text-3xl font-black tracking-tight text-slate-950 sm:text-4xl">Join Auricity as a Broker</h1><p className="mt-2 max-w-2xl text-sm leading-6 text-slate-600">Create your professional broker profile and start growing your real-estate business.</p></div><div className="text-right text-xs font-bold text-slate-500">Step {step} of 5</div></div><div className="mt-8 grid grid-cols-5 gap-2">{titles.map((t,i)=><button key={t} onClick={() => i+1 < step && setStep(i+1)} className="group text-left"><div className={`h-2 rounded-full ${i+1 <= step ? 'bg-[#214E9B]' : 'bg-slate-200'}`} /><p className={`mt-2 hidden text-[10px] font-bold sm:block ${i+1===step?'text-[#214E9B]':'text-slate-400'}`}>{i+1}. {t}</p></button>)}</div>

      <div className="mt-10">{step===1&&<StepOne form={form} update={update} />}{step===2&&<StepTwo form={form} update={update} toggle={toggleSpecialization} />}{step===3&&<StepThree form={form} update={update} />}{step===4&&<StepFour form={form} update={update} handleFile={handleFile} uploadError={uploadError} setForm={setForm} setFilePayloads={setFilePayloads} />}{step===5&&<Review form={form} />}</div>
      <div className="mt-10 flex flex-col-reverse gap-3 border-t border-slate-100 pt-6 sm:flex-row sm:justify-between">{step>1?<button onClick={() => setStep(step-1)} className="rounded-2xl border border-slate-200 px-5 py-3 text-sm font-black text-slate-700">Back</button>:<span />}{step<5?<button disabled={!validateStep(step)} onClick={() => setStep(step+1)} className="rounded-2xl bg-[#102B59] px-6 py-3 text-sm font-black text-white disabled:cursor-not-allowed disabled:opacity-40">Continue <ArrowRight className="ml-2 inline h-4 w-4" /></button>:<button onClick={submit} disabled={submitting} className="rounded-2xl bg-[#214E9B] px-6 py-3 text-sm font-black text-white disabled:opacity-60">{submitting?'Submitting…':'Submit Registration'} <Check className="ml-2 inline h-4 w-4" /></button>}</div>
      <p className="mt-5 flex items-start gap-2 text-xs leading-5 text-slate-500"><LockKeyhole className="mt-0.5 h-4 w-4 shrink-0" /> Submitted information is used for broker verification and handled securely. Only information needed to review your professional eligibility should be submitted.</p>
    </div></div></div>;
}

function Label({ children, required=false }: any) { return <label className="mb-1.5 block text-xs font-extrabold text-slate-800">{children} {required&&<span className="text-red-500">*</span>}</label>; }
function StepOne({form,update}:any){return <div><h2 className="text-xl font-black">Step 1 — Personal Information</h2><div className="mt-6 grid gap-5 sm:grid-cols-2"><div><Label required>Full Name</Label><input className={fieldClass(!form.personal.fullName)} value={form.personal.fullName} onChange={e=>update('personal','fullName',e.target.value)} placeholder="Your full name" /></div><div><Label required>Email Address</Label><input type="email" className={fieldClass(!form.personal.email)} value={form.personal.email} onChange={e=>update('personal','email',e.target.value)} placeholder="you@example.com" /></div><div><Label required>Mobile Number</Label><input type="tel" className={fieldClass(!form.personal.mobile)} value={form.personal.mobile} onChange={e=>update('personal','mobile',e.target.value)} placeholder="10-digit mobile number" /></div><div><Label>Profile Photo</Label><input type="file" accept="image/jpeg,image/png" className={fieldClass()} onChange={e=>{const f=e.target.files?.[0];if(f)update('personal','profilePhoto',URL.createObjectURL(f))}} /></div><div><Label required>City</Label><input className={fieldClass(!form.personal.city)} value={form.personal.city} onChange={e=>update('personal','city',e.target.value)} placeholder="City" /></div><div><Label required>State</Label><input className={fieldClass(!form.personal.state)} value={form.personal.state} onChange={e=>update('personal','state',e.target.value)} placeholder="State" /></div><div className="sm:col-span-2"><Label required>Preferred Language</Label><select className={fieldClass()} value={form.personal.preferredLanguage} onChange={e=>update('personal','preferredLanguage',e.target.value)}><option>English</option><option>Hindi</option><option>Marathi</option></select></div></div></div>}
function StepTwo({form,update,toggle}:any){const specs:Specialization[]=['Residential','Commercial','Land','Rental','Luxury','Other'];return <div><h2 className="text-xl font-black">Step 2 — Professional Information</h2><div className="mt-6 grid gap-5 sm:grid-cols-2"><div><Label required>Agency / Company Name</Label><input className={fieldClass(!form.professional.agencyName)} value={form.professional.agencyName} onChange={e=>update('professional','agencyName',e.target.value)} placeholder="Agency name" /></div><div><Label required>Years of Experience</Label><input type="number" min="0" className={fieldClass(!form.professional.yearsExperience)} value={form.professional.yearsExperience} onChange={e=>update('professional','yearsExperience',e.target.value)} placeholder="e.g. 5" /></div><div className="sm:col-span-2"><Label required>Specialization</Label><div className="flex flex-wrap gap-2">{specs.map(s=><button type="button" key={s} onClick={()=>toggle(s)} className={`rounded-full border px-4 py-2 text-xs font-bold ${form.professional.specialization.includes(s)?'border-[#214E9B] bg-[#EEF4FF] text-[#214E9B]':'border-slate-200 bg-white text-slate-600'}`}>{s}</button>)}</div></div><div className="sm:col-span-2"><Label required>Areas / Locations Served</Label><input className={fieldClass(!form.professional.areasServed)} value={form.professional.areasServed} onChange={e=>update('professional','areasServed',e.target.value)} placeholder="Areas, localities or cities" /></div><div className="sm:col-span-2"><Label required>Professional Bio</Label><textarea rows={5} className={fieldClass(!form.professional.bio)} value={form.professional.bio} onChange={e=>update('professional','bio',e.target.value)} placeholder="Briefly describe your professional experience and focus." /></div></div></div>}
function StepThree({form,update}:any){return <div><h2 className="text-xl font-black">Step 3 — Business Details</h2><div className="mt-6 grid gap-5 sm:grid-cols-2"><div className="sm:col-span-2"><Label required>Office Address</Label><textarea rows={3} className={fieldClass(!form.business.officeAddress)} value={form.business.officeAddress} onChange={e=>update('business','officeAddress',e.target.value)} /></div><div><Label required>Business Phone</Label><input className={fieldClass(!form.business.businessPhone)} value={form.business.businessPhone} onChange={e=>update('business','businessPhone',e.target.value)} /></div><div><Label>Website</Label><input className={fieldClass()} value={form.business.website} onChange={e=>update('business','website',e.target.value)} placeholder="https://" /></div><div className="sm:col-span-2"><Label required>Business Description</Label><textarea rows={4} className={fieldClass(!form.business.businessDescription)} value={form.business.businessDescription} onChange={e=>update('business','businessDescription',e.target.value)} /></div><div><Label required>Number of Active Properties</Label><input type="number" min="0" className={fieldClass(!form.business.activeProperties)} value={form.business.activeProperties} onChange={e=>update('business','activeProperties',e.target.value)} /></div><div><Label required>Preferred Property Types</Label><input className={fieldClass(!form.business.preferredPropertyTypes)} value={form.business.preferredPropertyTypes} onChange={e=>update('business','preferredPropertyTypes',e.target.value)} placeholder="e.g. 2 BHK, villas, plots" /></div></div></div>}
function StepFour({form,update,handleFile,uploadError,setForm,setFilePayloads}:any){return <div><h2 className="text-xl font-black">Step 4 — Verification</h2><p className="mt-2 text-sm text-slate-600">Submit only the government/professional identification information required for verification.</p><div className="mt-6 space-y-5"><div><Label required>Government / Professional identification type</Label><select className={fieldClass(!form.verification.idType)} value={form.verification.idType} onChange={e=>update('verification','idType',e.target.value)}><option value="">Select document type</option><option>RERA / Professional Registration</option><option>Government ID</option><option>Business Registration</option></select></div><div><Label required>Verification document upload</Label><label className="flex cursor-pointer flex-col items-center justify-center rounded-3xl border-2 border-dashed border-slate-300 bg-slate-50 px-6 py-10 text-center transition hover:border-[#214E9B] hover:bg-blue-50"><UploadCloud className="h-8 w-8 text-[#214E9B]" /><p className="mt-3 text-sm font-black">Drag & drop or choose a document</p><p className="mt-1 text-xs text-slate-500">PDF, JPG or PNG · maximum 5 MB</p><input type="file" accept="application/pdf,image/jpeg,image/png" className="hidden" onChange={e=>{const f=e.target.files?.[0];if(f)handleFile(f)}} /></label>{uploadError&&<p className="mt-2 text-xs font-bold text-red-600">{uploadError}</p>}<div className="mt-3 space-y-2">{form.verification.documents.map((d:BrokerDocument)=><div key={d.id} className="flex items-center justify-between rounded-2xl border border-slate-200 p-3"><div className="flex items-center gap-3"><FileCheck2 className="h-5 w-5 text-emerald-600" /><div><p className="text-xs font-black">{d.name}</p><p className="text-[10px] text-slate-500">{(d.size/1024/1024).toFixed(2)} MB</p></div></div><button type="button" onClick={()=>{setFilePayloads((p:any)=>{const n={...p}; delete n[d.id]; return n}); setForm((p:FormState)=>({...p,verification:{...p.verification,documents:p.verification.documents.filter(x=>x.id!==d.id)}}))}}><X className="h-4 w-4 text-slate-400" /></button></div>)}</div></div><div><Label>Business registration details (optional where applicable)</Label><textarea rows={3} className={fieldClass()} value={form.verification.businessRegistration} onChange={e=>update('verification','businessRegistration',e.target.value)} placeholder="Registration number or relevant details, if applicable" /></div><label className="flex items-start gap-3 rounded-2xl border border-slate-200 bg-white p-4"><input type="checkbox" className="mt-1 h-4 w-4 accent-[#214E9B]" checked={form.verification.agreement} onChange={e=>update('verification','agreement',e.target.checked)} /><span className="text-xs leading-5 text-slate-600">I confirm that the information submitted is accurate and I understand that it will be used for broker verification and handled securely. <span className="text-red-500">*</span></span></label></div></div>}
function Review({form}:any){return <div><h2 className="text-xl font-black">Step 5 — Review & Submit</h2><div className="mt-6 grid gap-4 sm:grid-cols-2">{[['Personal Information',form.personal],['Professional Information',form.professional],['Business Details',form.business],['Verification',form.verification]].map(([title,data]:any)=><div key={title} className="rounded-3xl border border-slate-200 bg-slate-50 p-5"><div className="flex items-center justify-between"><h3 className="text-sm font-black">{title}</h3><Pencil className="h-4 w-4 text-slate-400" /></div><div className="mt-4 space-y-2">{Object.entries(data).filter(([k])=>k!=='profilePhoto'&&k!=='documents'&&k!=='agreement').map(([k,v])=><div key={k} className="text-xs"><span className="font-bold capitalize text-slate-500">{k.replace(/([A-Z])/g,' $1')}: </span><span className="font-semibold text-slate-800">{Array.isArray(v)?v.join(', '):String(v||'—')}</span></div>)}</div></div>)}</div></div>}
function SuccessScreen({application,go}:any){return <div className="min-h-screen bg-[#F7F9FC] px-5 py-16"><div className="mx-auto max-w-xl rounded-[2rem] border border-slate-200 bg-white p-8 text-center shadow-xl sm:p-12"><div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-emerald-50 text-emerald-600"><CheckCircle2 className="h-8 w-8" /></div><h1 className="mt-6 text-3xl font-black">Registration Submitted Successfully!</h1><p className="mt-3 text-sm leading-6 text-slate-600">Your broker application has been received. Our team will review your information and notify you about the next steps.</p><div className="mt-8 grid gap-3 text-left sm:grid-cols-2"><div className="rounded-2xl bg-slate-50 p-4"><p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Application ID</p><p className="mt-1 font-black text-[#102B59]">{application.applicationId}</p></div><div className="rounded-2xl bg-slate-50 p-4"><p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Application Status</p><p className="mt-1 font-black text-amber-700">Under Review</p></div></div><div className="mt-7 flex flex-col gap-3 sm:flex-row"><button onClick={()=>go('broker-dashboard')} className="flex-1 rounded-2xl bg-[#102B59] px-5 py-3 text-sm font-black text-white">Go to Dashboard</button><button onClick={()=>go('broker-status')} className="flex-1 rounded-2xl border border-slate-200 px-5 py-3 text-sm font-black">View Application Status</button></div></div></div>}

function StatusPage({applications,loading,go,onSelect,selected}:any){return <div className="min-h-screen bg-[#F7F9FC] px-5 py-10 sm:px-8 lg:py-16"><div className="mx-auto max-w-6xl"><div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between"><div><p className="text-xs font-extrabold uppercase tracking-[.2em] text-[#B68A32]">Broker Application</p><h1 className="mt-2 text-3xl font-black">Application Status</h1><p className="mt-2 text-sm text-slate-600">Registration Submitted → Verification → Review → Decision</p></div><button onClick={()=>go('broker-register')} className="rounded-2xl bg-[#102B59] px-5 py-3 text-sm font-black text-white">Update Application</button></div>{loading?<div className="mt-10 rounded-3xl bg-white p-10 text-center">Loading…</div>:applications.length===0?<div className="mt-10 rounded-3xl border border-dashed border-slate-300 bg-white p-10 text-center"><ClipboardCheck className="mx-auto h-8 w-8 text-slate-400" /><h2 className="mt-4 font-black">No broker application found</h2><p className="mt-2 text-sm text-slate-500">Start your application to see its status here.</p><button onClick={()=>go('broker-register')} className="mt-5 rounded-2xl bg-[#214E9B] px-5 py-3 text-sm font-black text-white">Start Registration</button></div>:<div className="mt-8 grid gap-6 lg:grid-cols-[.8fr_1.2fr]"><div className="space-y-3">{applications.map((a:BrokerApplication)=><button key={a.id} onClick={()=>onSelect(a)} className={`w-full rounded-3xl border bg-white p-5 text-left transition hover:shadow-lg ${selected?.id===a.id?'border-[#214E9B] ring-4 ring-blue-50':'border-slate-200'}`}><div className="flex items-start justify-between gap-3"><div><p className="font-black">{a.personal.fullName}</p><p className="mt-1 text-xs text-slate-500">{a.applicationId}</p></div><StatusPill status={a.status} /></div><p className="mt-4 text-xs text-slate-500">Updated {new Date(a.updatedAt).toLocaleDateString()}</p></button>)}</div><div className="rounded-[2rem] border border-slate-200 bg-white p-6 sm:p-8">{selected?<><div className="flex items-start justify-between"><div><p className="text-xs font-bold uppercase tracking-wider text-slate-400">Application</p><h2 className="mt-1 text-2xl font-black">{selected.applicationId}</h2></div><StatusPill status={selected.status} /></div><div className="mt-8 grid gap-4 md:grid-cols-4">{['Registration Submitted','Verification','Review','Decision'].map((x,i)=><div key={x}><div className={`h-2 rounded-full ${selected.status==='approved' || (selected.status==='under_review'&&i<3)||i<2?'bg-[#214E9B]':'bg-slate-200'}`} /><p className="mt-2 text-xs font-bold text-slate-600">{x}</p></div>)}</div>{selected.status==='more_information_required'&&<div className="mt-8 flex gap-3 rounded-2xl border border-blue-200 bg-blue-50 p-4 text-sm text-blue-900"><AlertCircle className="h-5 w-5 shrink-0" /><div><p className="font-black">Additional information required</p><p className="mt-1 text-xs leading-5">Please update the application with the information requested by the Auricity review team.</p><button onClick={()=>go('broker-register')} className="mt-3 rounded-xl bg-[#214E9B] px-4 py-2 text-xs font-black text-white">Update Application</button></div></div>}{selected.status==='approved'&&<div className="mt-8 rounded-2xl bg-emerald-50 p-5 text-emerald-900"><p className="font-black">You were added to the Auricity Broker Program.</p><p className="mt-1 text-xs">Your broker profile is approved. You can now access your broker workspace.</p><button onClick={()=>go('broker-dashboard')} className="mt-4 rounded-xl bg-emerald-700 px-4 py-2 text-xs font-black text-white">Go to Dashboard</button></div>}</>:<div className="flex min-h-[400px] items-center justify-center text-center"><div><ClipboardCheck className="mx-auto h-8 w-8 text-slate-300" /><p className="mt-3 text-sm font-bold text-slate-500">Select an application to view its timeline.</p></div></div>}</div></div>}</div></div>}

function BrokerDashboard({app,allProperties,leads,realtors,go}:any){const own = app ? allProperties.filter((p:any)=>p.brokerId===app.id||p.brokerName===app.personal.fullName) : []; const ownLeads=app?leads.filter((l:any)=>l.assignedBrokerId===app.id||l.assignedBrokerName===app.personal.fullName):[]; const broker = realtors.find((r:Realtor)=>r.email===app?.personal.email); return <div className="min-h-screen bg-[#F7F9FC] px-5 py-10 sm:px-8 lg:py-16"><div className="mx-auto max-w-7xl"><div className="rounded-[2rem] bg-[#081A38] p-6 text-white sm:p-8"><div className="flex flex-col gap-5 sm:flex-row sm:items-center sm:justify-between"><div><div className="flex items-center gap-2"><BadgeCheck className="h-5 w-5 text-[#D9B45B]" /><span className="text-xs font-bold text-blue-200">Broker Workspace</span></div><h1 className="mt-2 text-3xl font-black">Welcome{app?.personal.fullName?`, ${app.personal.fullName.split(' ')[0]}`:''}</h1><p className="mt-2 text-sm text-blue-100">{app?.professional.agencyName || 'Your professional Auricity dashboard'}</p></div><button onClick={()=>go('broker-status')} className="rounded-2xl bg-white/10 px-5 py-3 text-sm font-black backdrop-blur hover:bg-white/15">Application <StatusPill status={app?.status||'under_review'} /></button></div></div><div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-5">{[['Total Listings',own.length],['Active Listings',own.filter((p:any)=>p.status==='Active').length],['New Leads',ownLeads.filter((l:any)=>l.status==='new'||l.status==='New').length],['Property Views','—'],['Enquiries',ownLeads.length]].map(([a,b])=><div key={a as string} className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm"><p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">{a as string}</p><p className="mt-2 text-3xl font-black text-[#102B59]">{b as any}</p></div>)}</div><div className="mt-6 grid gap-6 lg:grid-cols-2"><div className="rounded-3xl border border-slate-200 bg-white p-6"><div className="flex items-center justify-between"><h2 className="font-black">Recent Leads</h2><Users className="h-5 w-5 text-slate-400" /></div>{ownLeads.length?ownLeads.slice(0,6).map((l:any)=><div key={l.id} className="mt-4 flex items-center justify-between rounded-2xl bg-slate-50 p-4"><div><p className="text-sm font-black">{l.name}</p><p className="mt-1 text-xs text-slate-500">{l.preferredLocality||l.localityPreference||'Property enquiry'}</p></div><span className="text-xs font-bold text-[#214E9B]">{l.status}</span></div>):<div className="py-12 text-center text-sm text-slate-500">No assigned leads yet.</div>}</div><div className="rounded-3xl border border-slate-200 bg-white p-6"><div className="flex items-center justify-between"><h2 className="font-black">Recent Properties</h2><Building2 className="h-5 w-5 text-slate-400" /></div>{own.length?own.slice(0,6).map((p:any)=><div key={p.id} className="mt-4 flex items-center justify-between rounded-2xl bg-slate-50 p-4"><div><p className="text-sm font-black">{p.title}</p><p className="mt-1 text-xs text-slate-500">{p.locality}</p></div><span className="text-xs font-bold">{p.priceDisplay}</span></div>):<div className="py-12 text-center text-sm text-slate-500">No broker-linked properties yet.</div>}</div></div>{broker&&<div className="mt-6 rounded-3xl border border-slate-200 bg-white p-6"><div className="flex items-center gap-4"><img src={broker.avatar} className="h-14 w-14 rounded-2xl object-cover" /><div><p className="font-black">{broker.name}</p><p className="text-xs text-slate-500">{broker.agencyName} · {broker.kycStatus}</p></div></div></div>}</div></div>}

function AccessDenied({go}:any){return <div className="min-h-[60vh] bg-[#F7F9FC] px-5 py-20 text-center"><ShieldCheck className="mx-auto h-10 w-10 text-slate-300" /><h1 className="mt-5 text-2xl font-black">Admin access required</h1><p className="mt-2 text-sm text-slate-500">Open the protected admin area and authenticate before managing broker applications.</p><button onClick={()=>go('admin-hub')} className="mt-6 rounded-2xl bg-[#102B59] px-5 py-3 text-sm font-black text-white">Open Admin</button></div>}

function AdminPortal({adminPin,applications,allApplications,stats,filter,setFilter,search,setSearch,selected,setSelected,note,setNote,updateApplication,mobileMenu,setMobileMenu,go}:any){return <div className="min-h-screen bg-[#F4F7FB] px-4 py-6 sm:px-6 lg:px-8"><div className="mx-auto max-w-7xl"><div className="rounded-[2rem] bg-[#081A38] p-6 text-white sm:p-8"><div className="flex items-start justify-between gap-4"><div><div className="flex items-center gap-2"><ShieldCheck className="h-5 w-5 text-[#D9B45B]" /><span className="text-xs font-bold text-blue-200">Admin · Broker Management</span></div><h1 className="mt-2 text-3xl font-black">Broker Applications</h1><p className="mt-2 max-w-2xl text-sm text-blue-100">Review submitted profiles, verification details and application status.</p></div><button onClick={()=>setMobileMenu(!mobileMenu)} className="rounded-xl bg-white/10 p-2 md:hidden"><Menu className="h-5 w-5" /></button></div></div><div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">{[['Total Brokers',stats.total,Users],['Pending Applications',stats.pending,Clock3],['Verified Brokers',stats.approved,BadgeCheck],['Rejected Applications',stats.rejected,XCircle]].map(([t,n,I]:any)=><div key={t} className="rounded-3xl border border-slate-200 bg-white p-5"><I className="h-5 w-5 text-[#214E9B]" /><p className="mt-4 text-xs font-bold text-slate-500">{t}</p><p className="mt-1 text-3xl font-black">{n}</p></div>)}</div><div className="mt-5 grid gap-5 lg:grid-cols-[.9fr_1.1fr]"><div className="rounded-3xl border border-slate-200 bg-white p-4"><div className="flex flex-col gap-3 sm:flex-row"><div className="relative flex-1"><Search className="absolute left-3 top-3 h-4 w-4 text-slate-400" /><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search broker, email or application ID" className="w-full rounded-xl border border-slate-200 py-2.5 pl-9 pr-3 text-xs outline-none focus:border-[#214E9B]" /></div><select value={filter} onChange={e=>setFilter(e.target.value)} className="rounded-xl border border-slate-200 px-3 py-2.5 text-xs font-bold"><option value="all">All statuses</option><option value="under_review">Under Review</option><option value="approved">Approved</option><option value="rejected">Rejected</option><option value="more_information_required">More Information Required</option></select></div><div className="mt-4 space-y-2">{applications.map((a:BrokerApplication)=><button key={a.id} onClick={()=>setSelected(a)} className={`w-full rounded-2xl border p-4 text-left transition ${selected?.id===a.id?'border-[#214E9B] bg-blue-50':'border-slate-200 bg-white hover:bg-slate-50'}`}><div className="flex items-start justify-between gap-3"><div><p className="text-sm font-black">{a.personal.fullName}</p><p className="mt-1 text-[11px] text-slate-500">{a.professional.agencyName} · {a.applicationId}</p></div><StatusPill status={a.status} /></div><p className="mt-2 text-[11px] text-slate-400">{a.personal.email} · {a.personal.city}, {a.personal.state}</p></button>)}{!applications.length&&<div className="py-12 text-center text-sm text-slate-500">No applications match the current filters.</div>}</div></div><div className="rounded-3xl border border-slate-200 bg-white p-5 sm:p-7">{selected?<><div className="flex flex-col gap-4 border-b border-slate-100 pb-5 sm:flex-row sm:items-start sm:justify-between"><div><p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Application ID</p><h2 className="mt-1 text-2xl font-black">{selected.applicationId}</h2><p className="mt-1 text-sm text-slate-500">Submitted {new Date(selected.submittedAt).toLocaleString()}</p></div><StatusPill status={selected.status} /></div><div className="mt-6 grid gap-5 sm:grid-cols-2">{[['Personal',selected.personal],['Professional',selected.professional],['Business',selected.business],['Verification',selected.verification]].map(([title,data]:any)=><div key={title} className="rounded-2xl bg-slate-50 p-4"><h3 className="text-xs font-black uppercase tracking-wider text-slate-500">{title}</h3><div className="mt-3 space-y-2">{Object.entries(data).filter(([k])=>k!=='profilePhoto'&&k!=='documents').map(([k,v])=><div key={k} className="text-xs"><span className="font-bold text-slate-500 capitalize">{k.replace(/([A-Z])/g,' $1')}: </span><span className="font-semibold text-slate-800">{Array.isArray(v)?v.join(', '):String(v||'—')}</span></div>)}</div></div>)}</div><div className="mt-5"><h3 className="text-sm font-black">Verification Documents</h3>{selected.verification.documents.length?<div className="mt-3 space-y-2">{selected.verification.documents.map((d:BrokerDocument)=><div key={d.id} className="flex items-center justify-between rounded-2xl border border-slate-200 p-3"><div className="flex items-center gap-3"><FileText className="h-5 w-5 text-[#214E9B]" /><div><p className="text-xs font-black">{d.name}</p><p className="text-[10px] text-slate-500">{d.type} · {(d.size/1024/1024).toFixed(2)} MB</p></div></div>{d.storageKey ? <button type="button" onClick={async()=>{try{const r=await fetch(`/api/broker/documents/${d.storageKey}`,{headers:{'x-admin-pin':String(adminPin)}});if(!r.ok)throw new Error();const blob=await r.blob();const url=URL.createObjectURL(blob);window.open(url,'_blank','noopener,noreferrer');setTimeout(()=>URL.revokeObjectURL(url),30000)}catch{alert('Unable to open document.')}}} className="rounded-xl bg-[#102B59] px-3 py-1.5 text-[10px] font-black text-white">View Document</button> : <span className="rounded-xl bg-slate-100 px-3 py-1.5 text-[10px] font-bold text-slate-500">Upload pending</span>}</div>)}</div>:<p className="mt-2 text-xs text-slate-500">No documents submitted.</p>}</div><div className="mt-6 rounded-2xl border border-slate-200 p-4"><Label>Admin note / review reason</Label><textarea rows={3} value={note} onChange={e=>setNote(e.target.value)} className={fieldClass()} placeholder="Optional internal note or request for additional information" /><div className="mt-4 flex flex-wrap gap-2"><button onClick={()=>updateApplication(selected,{status:'approved',reviewerNotes:note})} className="rounded-xl bg-emerald-700 px-4 py-2.5 text-xs font-black text-white">Approve Broker</button><button onClick={()=>updateApplication(selected,{status:'more_information_required',reviewerNotes:note})} className="rounded-xl bg-blue-700 px-4 py-2.5 text-xs font-black text-white">Request Information</button><button onClick={()=>updateApplication(selected,{status:'rejected',reviewerNotes:note})} className="rounded-xl bg-red-600 px-4 py-2.5 text-xs font-black text-white">Reject</button></div></div></>:<div className="flex min-h-[550px] items-center justify-center text-center"><div><FileCheck2 className="mx-auto h-9 w-9 text-slate-300" /><p className="mt-4 text-sm font-bold text-slate-500">Select an application to review.</p></div></div>}</div></div><div className="mt-5 rounded-2xl border border-amber-200 bg-amber-50 p-4 text-xs leading-5 text-amber-900"><strong>Security note:</strong> verification documents are represented here as private application records. In production, keep file bytes in private object storage and issue short-lived authorized access rather than public file URLs.</div></div></div>}
