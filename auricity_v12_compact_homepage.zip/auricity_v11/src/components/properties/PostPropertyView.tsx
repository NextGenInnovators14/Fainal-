import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { 
  Building2, 
  MapPin, 
  IndianRupee, 
  BedDouble, 
  Maximize2, 
  Sparkles, 
  CheckCircle2, 
  UploadCloud, 
  Image as ImageIcon,
  ShieldCheck,
  User,
  PhoneCall,
  PlusCircle,
  Clock,
  Zap
} from 'lucide-react';
import confetti from 'canvas-confetti';

export const PostPropertyView: React.FC = () => {
  const { addProperty, localitiesList, showToast, setActiveView } = useApp();

  const [listingType, setListingType] = useState<'sale' | 'rent' | 'pg'>('sale');
  const [propertyType, setPropertyType] = useState('Flat / Apartment');
  const [bhk, setBhk] = useState<number>(2);
  const [locality, setLocality] = useState(localitiesList[0] || 'CIDCO');
  const [address, setAddress] = useState('');
  const [price, setPrice] = useState<number>(4500000);
  const [area, setArea] = useState<number>(1050);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [ownerName, setOwnerName] = useState('');
  const [ownerPhone, setOwnerPhone] = useState('');
  const [furnishing, setFurnishing] = useState('Semi-Furnished');
  const [amenities, setAmenities] = useState<string[]>(['Lift', 'Reserved Parking', '24/7 Water Supply']);
  const [reraId, setReraId] = useState('');
  const [imageUrl, setImageUrl] = useState('https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=800&auto=format&fit=crop&q=60');

  const [aiGenerating, setAiGenerating] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const amenityOptions = [
    'Lift',
    'Reserved Parking',
    '24/7 Water Supply',
    'Power Backup',
    'CCTV Security',
    'Club House',
    'Children Play Area',
    'Gymnasium',
    'Solar Water Heater',
    'Vastu Compliant',
    'Gated Society',
    'Gas Pipeline'
  ];

  const handleToggleAmenity = (item: string) => {
    if (amenities.includes(item)) {
      setAmenities(amenities.filter(a => a !== item));
    } else {
      setAmenities([...amenities, item]);
    }
  };

  // AI Description Generator via Backend Gemini Route
  const handleGenerateAIDescription = async () => {
    if (!locality || !propertyType) {
      showToast('Please select property type and locality first', 'error');
      return;
    }

    setAiGenerating(true);
    try {
      const response = await fetch('/api/ai/enhance-listing', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: title || `${bhk} BHK ${propertyType} in ${locality}`,
          locality,
          propertyType,
          bhk,
          area,
          price,
          amenities
        })
      });

      if (!response.ok) {
        throw new Error('AI Service request failed');
      }

      const data = await response.json();
      if (data.enhancedTitle) setTitle(data.enhancedTitle);
      if (data.enhancedDescription) setDescription(data.enhancedDescription);
      showToast('AI Listing Title & Description Generated!', 'success');
    } catch (err) {
      // Fallback generator
      const fallbackDesc = `Spacious and well-ventilated ${bhk} BHK ${propertyType} situated in the prime locality of ${locality}, Chhatrapati Sambhajinagar. Offering ${area} sq.ft of super built-up space, featuring ${furnishing.toLowerCase()} interiors, 24/7 water supply, power backup, and dedicated parking. Prime connectivity to schools, hospitals, and markets with 0% brokerage directly from owner.`;
      setDescription(fallbackDesc);
      if (!title) setTitle(`Prime ${bhk} BHK ${propertyType} with Modern Amenities in ${locality}`);
      showToast('Generated description using local templates', 'info');
    } finally {
      setAiGenerating(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!title || !price || !area || !ownerName || !ownerPhone) {
      showToast('Please fill all required fields', 'error');
      return;
    }

    setSubmitting(true);
    setTimeout(() => {
      const newProp = {
        id: `prop-user-${Date.now()}`,
        title,
        description: description || `${bhk} BHK ${propertyType} in ${locality}`,
        listingType,
        propertyType,
        bhk,
        price: Number(price),
        area: Number(area),
        locality,
        address: address || `${locality}, Chhatrapati Sambhajinagar`,
        furnishing,
        amenities,
        images: [imageUrl],
        contactName: ownerName,
        contactPhone: ownerPhone,
        verified: false,
        featured: false,
        status: 'active' as const,
        // A property submitted through this public, no-login form used to
        // go straight into the live public listings with zero review —
        // anyone could put anything on the site instantly. approvalStatus
        // and published already existed on the Property type for exactly
        // this case but were never actually set or checked anywhere.
        // Setting them here, combined with the public listing views now
        // filtering on them, means new self-submitted listings wait for
        // an admin to approve them in Properties before they go live —
        // same free/direct submission experience for the owner, just with
        // a review step before it's public.
        approvalStatus: 'pending' as const,
        published: false,
        reraId: reraId || undefined,
        createdAt: Date.now()
      };

      addProperty(newProp);
      setSubmitting(false);

      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 }
      });

      showToast('Property submitted! Our team will verify the details and it will go live shortly.', 'success');
      setActiveView('home');
    }, 600);
  };

  return (
    <div className="bg-[#F7F8FA] min-h-screen py-10">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        
        {/* Header Title */}
        <div className="bg-white p-6 sm:p-8 rounded-3xl border border-[#E2E8F0] shadow-xs space-y-2">
          <div className="inline-flex items-center space-x-2 bg-orange-50 text-[#F2621E] px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider border border-orange-100">
            <Zap className="w-3.5 h-3.5 fill-[#F2621E]" />
            <span>100% Free Owner Listing</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-[#0F172A] tracking-tight">
            Post Your Property for Free in Sambhajinagar
          </h1>
          <p className="text-xs text-[#64748B]">
            Reach thousands of verified buyers and tenants directly. Zero commission, instant WhatsApp leads, and optional Gemini AI listing enhancement.
          </p>
        </div>

        {/* Listing Creation Form */}
        <form onSubmit={handleSubmit} className="space-y-6">
          
          {/* 1. Basic Type & Classification */}
          <div className="bg-white p-6 rounded-3xl border border-[#E2E8F0] shadow-xs space-y-4">
            <h3 className="text-sm font-black uppercase tracking-wider text-[#0F172A] flex items-center space-x-2">
              <Building2 className="w-4 h-4 text-[#1E4FA8]" />
              <span>1. Property Purpose & Classification</span>
            </h3>

            {/* Listing Type Tabs */}
            <div className="grid grid-cols-3 gap-3">
              {[
                { id: 'sale', label: 'Sell Property' },
                { id: 'rent', label: 'Rent Out' },
                { id: 'pg', label: 'PG / Co-Living' }
              ].map(t => (
                <button
                  type="button"
                  key={t.id}
                  onClick={() => setListingType(t.id as any)}
                  className={`py-3 px-4 rounded-2xl text-xs font-black transition-all border text-center cursor-pointer ${
                    listingType === t.id
                      ? 'bg-[#1E4FA8] text-white border-[#1E4FA8] shadow-xs'
                      : 'bg-[#F7F8FA] text-[#0F172A] border-[#E2E8F0] hover:border-[#1E4FA8]/40'
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
              {/* Property Type */}
              <div>
                <label className="text-[11px] font-bold text-[#0F172A] block mb-1">
                  Property Category *
                </label>
                <select
                  value={propertyType}
                  onChange={(e) => setPropertyType(e.target.value)}
                  className="w-full px-3 py-2.5 bg-[#F7F8FA] border border-[#E2E8F0] rounded-xl text-xs font-bold text-[#0F172A] focus:outline-none focus:border-[#1E4FA8]"
                >
                  <option value="Flat / Apartment">Flat / Apartment</option>
                  <option value="Row House / Villa">Row House / Villa</option>
                  <option value="Residential Plot">NA Plot / Land</option>
                  <option value="Commercial Shop">Commercial Space / Shop</option>
                  <option value="Hostel / PG Room">Hostel / PG Room</option>
                </select>
              </div>

              {/* BHK */}
              <div>
                <label className="text-[11px] font-bold text-[#0F172A] block mb-1">
                  BHK Configuration
                </label>
                <select
                  value={bhk}
                  onChange={(e) => setBhk(Number(e.target.value))}
                  className="w-full px-3 py-2.5 bg-[#F7F8FA] border border-[#E2E8F0] rounded-xl text-xs font-bold text-[#0F172A] focus:outline-none focus:border-[#1E4FA8]"
                >
                  <option value={1}>1 BHK</option>
                  <option value={2}>2 BHK</option>
                  <option value={3}>3 BHK</option>
                  <option value={4}>4 BHK</option>
                  <option value={5}>5+ BHK</option>
                </select>
              </div>

              {/* Furnishing */}
              <div>
                <label className="text-[11px] font-bold text-[#0F172A] block mb-1">
                  Furnishing Status
                </label>
                <select
                  value={furnishing}
                  onChange={(e) => setFurnishing(e.target.value)}
                  className="w-full px-3 py-2.5 bg-[#F7F8FA] border border-[#E2E8F0] rounded-xl text-xs font-bold text-[#0F172A] focus:outline-none focus:border-[#1E4FA8]"
                >
                  <option value="Unfurnished">Unfurnished</option>
                  <option value="Semi-Furnished">Semi-Furnished</option>
                  <option value="Fully Furnished">Fully Furnished</option>
                </select>
              </div>
            </div>
          </div>

          {/* 2. Location & Pricing */}
          <div className="bg-white p-6 rounded-3xl border border-[#E2E8F0] shadow-xs space-y-4">
            <h3 className="text-sm font-black uppercase tracking-wider text-[#0F172A] flex items-center space-x-2">
              <MapPin className="w-4 h-4 text-[#F2621E]" />
              <span>2. Location & Pricing</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Locality */}
              <div>
                <label className="text-[11px] font-bold text-[#0F172A] block mb-1">
                  Locality / Neighborhood *
                </label>
                <select
                  value={locality}
                  onChange={(e) => setLocality(e.target.value)}
                  className="w-full px-3 py-2.5 bg-[#F7F8FA] border border-[#E2E8F0] rounded-xl text-xs font-bold text-[#0F172A] focus:outline-none focus:border-[#1E4FA8]"
                >
                  {localitiesList.map(loc => (
                    <option key={loc} value={loc}>{loc}</option>
                  ))}
                </select>
              </div>

              {/* Specific Address */}
              <div>
                <label className="text-[11px] font-bold text-[#0F172A] block mb-1">
                  Building / Society / Landmark
                </label>
                <input
                  type="text"
                  placeholder="e.g. Near Cannaught Garden, Sector N-3"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="w-full px-3 py-2.5 bg-[#F7F8FA] border border-[#E2E8F0] rounded-xl text-xs font-medium text-[#0F172A] focus:outline-none focus:border-[#1E4FA8]"
                />
              </div>

              {/* Price */}
              <div>
                <label className="text-[11px] font-bold text-[#0F172A] block mb-1">
                  {listingType === 'rent' ? 'Monthly Rent (₹) *' : 'Expected Total Price (₹) *'}
                </label>
                <input
                  type="number"
                  placeholder="e.g. 4500000"
                  value={price}
                  onChange={(e) => setPrice(Number(e.target.value))}
                  className="w-full px-3 py-2.5 bg-[#F7F8FA] border border-[#E2E8F0] rounded-xl text-xs font-bold text-[#0F172A] focus:outline-none focus:border-[#1E4FA8]"
                  required
                />
              </div>

              {/* Area */}
              <div>
                <label className="text-[11px] font-bold text-[#0F172A] block mb-1">
                  Super Built-up Area (Sq.Ft) *
                </label>
                <input
                  type="number"
                  placeholder="e.g. 1050"
                  value={area}
                  onChange={(e) => setArea(Number(e.target.value))}
                  className="w-full px-3 py-2.5 bg-[#F7F8FA] border border-[#E2E8F0] rounded-xl text-xs font-bold text-[#0F172A] focus:outline-none focus:border-[#1E4FA8]"
                  required
                />
              </div>
            </div>
          </div>

          {/* 3. AI Enhanced Listing Content */}
          <div className="bg-white p-6 rounded-3xl border border-[#E2E8F0] shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-black uppercase tracking-wider text-[#0F172A] flex items-center space-x-2">
                <Sparkles className="w-4 h-4 text-indigo-600" />
                <span>3. Title & Description (AI Assisted)</span>
              </h3>

              <button
                type="button"
                onClick={handleGenerateAIDescription}
                disabled={aiGenerating}
                className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white text-xs font-bold px-3 py-1.5 rounded-xl shadow-xs flex items-center space-x-1.5 cursor-pointer disabled:opacity-50"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>{aiGenerating ? 'Writing with Gemini AI...' : 'Auto-Generate with AI'}</span>
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="text-[11px] font-bold text-[#0F172A] block mb-1">
                  Listing Title *
                </label>
                <input
                  type="text"
                  placeholder="e.g. Spacious 2 BHK Flat with Garden View in CIDCO N-3"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full px-3 py-2.5 bg-[#F7F8FA] border border-[#E2E8F0] rounded-xl text-xs font-bold text-[#0F172A] focus:outline-none focus:border-[#1E4FA8]"
                  required
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-[#0F172A] block mb-1">
                  Detailed Description
                </label>
                <textarea
                  rows={4}
                  placeholder="Describe your flat, proximity to schools, road connectivity, water availability..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full px-3 py-2.5 bg-[#F7F8FA] border border-[#E2E8F0] rounded-xl text-xs font-medium text-[#0F172A] focus:outline-none focus:border-[#1E4FA8] resize-none"
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-[#0F172A] block mb-1">
                  Photo URL
                </label>
                <input
                  type="text"
                  value={imageUrl}
                  onChange={(e) => setImageUrl(e.target.value)}
                  className="w-full px-3 py-2.5 bg-[#F7F8FA] border border-[#E2E8F0] rounded-xl text-xs font-medium text-[#0F172A] focus:outline-none focus:border-[#1E4FA8]"
                />
              </div>
            </div>

            {/* Society Amenities Selector */}
            <div className="space-y-2 pt-2">
              <label className="text-[11px] font-bold text-[#0F172A] block">
                Select Amenities Available
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {amenityOptions.map((am) => {
                  const isChecked = amenities.includes(am);
                  return (
                    <button
                      type="button"
                      key={am}
                      onClick={() => handleToggleAmenity(am)}
                      className={`p-2 rounded-xl text-xs font-bold text-left border flex items-center space-x-2 transition-all cursor-pointer ${
                        isChecked 
                          ? 'bg-blue-50/80 border-[#1E4FA8] text-[#1E4FA8]' 
                          : 'bg-[#F7F8FA] border-[#E2E8F0] text-[#64748B] hover:border-slate-300'
                      }`}
                    >
                      <CheckCircle2 className={`w-3.5 h-3.5 ${isChecked ? 'text-[#1E4FA8]' : 'text-slate-300'}`} />
                      <span className="truncate">{am}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* 4. Owner Contact & MahaRERA */}
          <div className="bg-white p-6 rounded-3xl border border-[#E2E8F0] shadow-xs space-y-4">
            <h3 className="text-sm font-black uppercase tracking-wider text-[#0F172A] flex items-center space-x-2">
              <User className="w-4 h-4 text-[#16A34A]" />
              <span>4. Direct Owner Verification</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="text-[11px] font-bold text-[#0F172A] block mb-1">
                  Owner / Contact Name *
                </label>
                <input
                  type="text"
                  placeholder="e.g. Rameshwar Deshmukh"
                  value={ownerName}
                  onChange={(e) => setOwnerName(e.target.value)}
                  className="w-full px-3 py-2.5 bg-[#F7F8FA] border border-[#E2E8F0] rounded-xl text-xs font-medium text-[#0F172A] focus:outline-none focus:border-[#1E4FA8]"
                  required
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-[#0F172A] block mb-1">
                  10-Digit Mobile Number *
                </label>
                <input
                  type="tel"
                  placeholder="e.g. 9822012345"
                  value={ownerPhone}
                  onChange={(e) => setOwnerPhone(e.target.value)}
                  className="w-full px-3 py-2.5 bg-[#F7F8FA] border border-[#E2E8F0] rounded-xl text-xs font-medium text-[#0F172A] focus:outline-none focus:border-[#1E4FA8]"
                  required
                />
              </div>

              <div>
                <label className="text-[11px] font-bold text-[#0F172A] block mb-1">
                  MahaRERA Registration No. (Optional)
                </label>
                <input
                  type="text"
                  placeholder="e.g. P51500012345"
                  value={reraId}
                  onChange={(e) => setReraId(e.target.value)}
                  className="w-full px-3 py-2.5 bg-[#F7F8FA] border border-[#E2E8F0] rounded-xl text-xs font-medium text-[#0F172A] focus:outline-none focus:border-[#1E4FA8]"
                />
              </div>
            </div>
          </div>

          {/* Submit CTA */}
          <div className="pt-2">
            <button
              type="submit"
              disabled={submitting}
              className="w-full bg-[#F2621E] hover:bg-[#E0520F] text-white py-4 rounded-2xl font-black text-sm shadow-orange-brand transition-all flex items-center justify-center space-x-2 cursor-pointer disabled:opacity-50"
            >
              <PlusCircle className="w-5 h-5" />
              <span>{submitting ? 'Publishing Listing...' : 'Publish Property Listing with 0% Brokerage'}</span>
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
